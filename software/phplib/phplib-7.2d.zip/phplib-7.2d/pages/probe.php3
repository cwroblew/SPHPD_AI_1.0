<?php
  include($_PHPLIB["libdir"] . "table.inc");
  include($_PHPLIB["libdir"] . "sqlquery.inc");

  page_open(array("sess" => "Example_Session"));
  $sess->register("q");

  $db = new DB_Example;
  $t  = new Table;
  $t->heading = "on";
?>
<html>
<head><title>Testseite</title>
<style type="text/css"><!--
h1          { font-family: arial, helvetica, sans-serif; color: #d33e30 }
table.test  { background-color: #eeeeee }
th.test     { font-family: arial, helvetica, sans-serif  }
td.test     { font-family: arial, helvetica, sans-serif }
table.query { background-color: #cccccc }
td.query    { font-face: arial, helvetica, sans-serif }
--></style>
</head>
<body bgcolor="#ffffff">
<h1>Testseite</h1>
<?php
  $field = array(
    "sem_no_pre"         => "Veranstalternummer",
    "sem_no_inf"         => "Seminarnummer",
    "sem_no_lfd"         => "Laufende Nummer",
    "sem_beginn"         => "Seminarbeginn",
    "sem_ende"           => "Seminarende",
    "sem_tln_soll"       => "Sollteilnehmerzahl",
    "sem_tln_ist"        => "Istteilnehmerzahl",
    "sem_preis_dm"       => "Preis in DM",
    "sem_preis_euro"     => "Preis in EUR",
    "sem_plz"            => "Seminarort PLZ",
    "sem_ort"            => "Seminarort",
    "sem_strasse"        => "Seminarort Stra�e",
    "sem_raum"           => "Seminarraum",
    "unterk_bezeichnung" => "Unterkunft Name",
    "unterk_plz"         => "Unterkunft PLZ",
    "unterk_ort"         => "Unterkunft Ort",
    "unterk_strasse"     => "Unterkunft Stra�e",
    "unterk_preis_dm"    => "Unterkunft Preis in DM",
    "unterk_preis_euro"  => "Unterkunft Preis in EUR",
    "bemerkung"          => "Bemerkungen",
    "changed"            => "�nderungsdatum");

  if (!isset($q)) {
    $q = new Sql_Query;
    $q->translate = "on";
    $q->container = "on";
    $q->variable  = "on";
    $q->lang      = "de";
  }
  
  if (isset($x)) {
    $query = $q->where("x", 1);
  }

  printf($q->form("x", $field, "query"));
  printf("<hr>\n");

  if ($query) {
    printf("Query Condition = %s<br>\n", $query);
    $db->query("select * from sem_katalog where ". $query);
    printf("Query Results = %s<br>\n", $db->num_rows());
    $t->show_result($db, "test");
  }

  page_close();
?>
</body>
</html>
<!-- $Id: probe.php3,v 1.1.1.1 2000/04/17 16:40:07 kk Exp $ -->
