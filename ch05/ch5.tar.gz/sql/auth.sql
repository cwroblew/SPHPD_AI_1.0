# phpMyAdmin MySQL-Dump
# version 2.2.5
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Generation Time: May 14, 2002 at 01:55 PM
# Server version: 3.23.35
# PHP Version: 4.1.0
# Database : `auth`
# -------------------------------------------------------

#
# Table structure for table `users`
#

CREATE TABLE IF NOT EXISTS users (
  USER_ID int(11) NOT NULL auto_increment,
  EMAIL varchar(32) NOT NULL default '',
  PASSWORD varchar(128) NOT NULL default '',
  ACTIVE tinyint(4) NOT NULL default '0',
  TYPE tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (USER_ID),
  UNIQUE KEY EMAIL (EMAIL)
) TYPE=MyISAM COMMENT='User Authentication Table';

#
# Table structure for table `ACTIVITY`
#

CREATE TABLE IF NOT EXISTS ACTIVITY (
  USER_ID int(11) NOT NULL default '0',
  ACTION_TYPE tinyint(4) NOT NULL default '0',
  ACTION_TS bigint(20) NOT NULL default '0',
  PRIMARY KEY  (USER_ID,ACTION_TYPE,ACTION_TS)
) TYPE=MyISAM COMMENT='User Activity Log';


